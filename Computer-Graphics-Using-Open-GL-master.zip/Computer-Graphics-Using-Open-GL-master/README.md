# Computer-Graphics-Using-Open-GL

1. Code to draw a triangle

2. Creating a polygon

3. Creating line loop

4. Creating a linestrip

5. Creating a Triangle Fan

6. Creating a triangle strip

7. Self rotating triangle

8. Key press rotation

9. Self rotating polygon

10. Self rotating cube

11. Beizer Curve
